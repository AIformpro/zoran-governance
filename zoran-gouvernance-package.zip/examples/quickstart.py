from zgouv.core import GovernanceModule

gm = GovernanceModule()
print(gm.vote("prop1", "agent1", "oui"))
print("Quorum atteint :", gm.quorum_reached("prop1", threshold=1))
gm.set_reputation("agent1", 5)
print("Réputation agent1 :", gm.get_reputation("agent1"))
