from zgouv.core import GovernanceModule

def test_vote_and_quorum():
    gm = GovernanceModule()
    gm.vote("prop1", "agent1", "oui")
    assert gm.quorum_reached("prop1", threshold=1)
