class GovernanceModule:
    def __init__(self):
        self.votes = {}
        self.reputation = {}

    def vote(self, proposal, agent, choice):
        self.votes.setdefault(proposal, {})[agent] = choice
        return f"Vote enregistré pour {agent} sur {proposal} : {choice}"

    def quorum_reached(self, proposal, threshold=0.5):
        total_votes = len(self.votes.get(proposal, {}))
        return total_votes >= threshold

    def set_reputation(self, agent, score):
        self.reputation[agent] = score

    def get_reputation(self, agent):
        return self.reputation.get(agent, 0)
